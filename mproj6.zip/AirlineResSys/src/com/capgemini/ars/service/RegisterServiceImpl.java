package com.capgemini.ars.service;

import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.IAirlineDao;
import com.capgemini.ars.exception.AirlineException;

public class RegisterServiceImpl {


	IAirlineDao airlineDao;

	public IAirlineDao getAirlineDao() {
		return airlineDao;
	}

	public void setAirlineDao(IAirlineDao airlineDao) {
		this.airlineDao = airlineDao;
	}
	
	public void addUser(UserBean userDetails) throws AirlineException{
		return;
	}

	
}
