    import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.ars.bean.BookingInformationBean;
import com.capgemini.ars.bean.FlightInformationBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.AirlineDAOImplement;
import com.capgemini.ars.dao.IAirlineDao;
import com.capgemini.ars.service.AdminServiceImpl;
import com.capgemini.ars.service.AirlineExecutiveServiceImpl;
import com.capgemini.ars.service.IAdminService;
import com.capgemini.ars.service.IAirlineExecutiveService;
import com.capgemini.ars.service.ILoginService;
import com.capgemini.ars.service.IUserService;
import com.capgemini.ars.service.LoginServiceImpl;
import com.capgemini.ars.service.UserServiceImpl;



	public class TestClass{
		
		IAirlineDao IAirline;
		UserBean userbean;
		BookingInformationBean bibean;
		FlightInformationBean fibean;
		IAdminService  iaservice;
		IAirlineExecutiveService ieservice;
		ILoginService ilservice;
		IUserService iuservice;
		
		
		
		@Before
		public void setup(){
			
			IAirline= new AirlineDAOImplement();
			userbean=new UserBean();
			bibean=new BookingInformationBean();
			fibean=new FlightInformationBean();
			iaservice=new AdminServiceImpl();
			ieservice=new AirlineExecutiveServiceImpl();
			ilservice=new LoginServiceImpl();
			iuservice=new UserServiceImpl();
		}
		 @Test
		public void fetchAvailableFlights(){
			
			String deptCity="Pune";
			String arrCity="Jaipur";
			String deptDate="28-09-2018";
			
			int firstSeats=23;
			int bussSeats=10;
		    fibean.setDeptCity(deptCity);
		    
		    fibean.setArrCity(arrCity);
		    
		    //fibean.setDeptDate(deptDate);
		    
		    fibean.setFirstSeats(firstSeats);
		    
		    fibean.setBussSeats(bussSeats);
		    int k = fibean.getFirstSeats();
		    int y = fibean.getBussSeats();
			Assert.assertEquals(deptCity, fibean.getDeptCity());
			Assert.assertEquals(arrCity, fibean.getArrCity());
			Assert.assertEquals(deptDate, fibean.getDeptDate());
			Assert.assertEquals(firstSeats,k);
			Assert.assertEquals(bussSeats, y);
			
			
		}
		
		
		@Test
		public void retrieveBookingDetails(){
			
			int bookingId=11;
			
		     bibean.setBookingId(bookingId);
		     
		     int b=bibean.getBookingId();
		     
		     Assert.assertEquals(bookingId,b);
		}


        @Test
        
        public void isValidUserLogin(){
        	
        	String Username = "Swapnil123";
        	String password = "Capg123";
        	
        	
        	userbean.setUserName(Username);
        	userbean.setPassword(password);
        	
        	Assert.assertEquals(Username, userbean.getUserName());
        	Assert.assertEquals(password, userbean.getPassword());
        	
        }
        
     @Test
     public void  fetchGivenCityFlights()
     {
    	 
       String deptcity= "mumbai";
       String arrcity="Pune";
       
       fibean.setDeptCity(deptcity);
       fibean.setArrCity(arrcity);
       
        Assert.assertEquals(deptcity, fibean.getDeptCity());
        Assert.assertEquals(arrcity, fibean.getArrCity());
        
       
 
     }
     
     @Test
     
     public void retrieveFlightDetails()
     {
    	 
    	 int flightnumber = 30;
    	 
    	 fibean.setFlightNo(flightnumber);
    	 
    	 Assert.assertEquals(flightnumber, fibean.getFlightNo());
     }
        	
     @Test
     
     public void fetchGivenPeriodFlights(){
    	 
    	 String airline ="air";
    	 String deptDate= "29-11-2018";
    	 String deptTime = "123";
    	 
    	 fibean.setAirline(airline);
    	 fibean.setDeptCity(deptDate);
    	 fibean.setDeptTime(deptTime);
    	 
    	 Assert.assertEquals(airline, fibean.getAirline());
    	 Assert.assertEquals(deptDate, fibean.getDeptCity());
    	 Assert.assertEquals(deptTime, fibean.getDeptTime());
    	 
     }
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        	
        }
