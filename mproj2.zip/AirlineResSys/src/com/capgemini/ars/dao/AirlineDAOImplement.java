package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.OrderNotFoundException;
import com.capgemini.ars.bean.BookingInformationBean;
import com.capgemini.ars.bean.FlightInformationBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.AirlineException;
import com.capgemini.donorapplication.dao.QueryMapper;
import com.capgemini.donorapplication.exception.DonorException;
import com.capgemini.dto.OrderDTO;


public class AirlineDAOImplement implements IAirlineDao {
	
	//beans of reqd fields to contain information
	ArrayList<FlightInformationBean> flightList = null;
	//FlightInformationBean flightDetails = null;
	BookingInformationBean bookingDetails = null;
	UserBean userDetails = null;
	ArrayList<String> cityList = null;
	
	//default constructor
	public AirlineDAOImplement() {
		super();
	}

	
	
	// start fetchAvailableFlights
	@Override
	public ArrayList<FlightInformationBean> fetchAvailableFlights(FlightInformationBean flightInfo, String classType,
			int noOfPassengers) throws AirlineException {
		
		if (classType.equalsIgnoreCase("first")) 
		{
		
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.CHECK_FIRST_CLASS_AVAILABILITY);
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
					
					flightList.add(flight);
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
		}
		else if (classType.equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.CHECK_BUSINESS_CLASS_AVAILABILITY);
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
					
					flightList.add(flight);
				
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.toString());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
		}
		
		return null;
	}
	//END fetchAvailableFlights-----------------------------------------------------------------------------------
	
//=======================================================================================================================================
//==================================================================================================================================================	
	// start bookFlight
	@Override
	public int bookFlight(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		
		decOccupancy(bookingInfo, passengers);
		bookDetails(bookingInfo);
		int bookingId = bookingInfo.getBookingId();
		return bookingId;
		
	}
	
	


	//function to reduce the availabe seats after a booking
	private void decOccupancy(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		if (bookingInfo.getClassType().equalsIgnoreCase("first")) 
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			//FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_FIRST_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
			
		}
		else if (bookingInfo.getClassType().equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			//FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_BUSINESS_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			
		}
		
		
	}
	
	
	//for generating booking id using sequence
	private int generateNextBookingId() throws SQLException {
		int id = 0;

		String selectQuery = "SELECT booking_id_seq.NEXTVAL FROM DUAL";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}
	
	//to enter the booking detail inside the db
	private void bookDetails(BookingInformationBean bookingInfo) 
	{
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		BookingInformationBean book = null;
		
		try
		{
			
			preparedStatement=connection.prepareStatement(IQueryMapper.BOOKING_DETAIL_INSERT);
			preparedStatement.setInt(1,generateNextBookingId());
			preparedStatement.setString(2,bookingInfo.getCustEmail());
			preparedStatement.setInt(3,bookingInfo.getNoOfPassengers());
			preparedStatement.setString(4,bookingInfo.getClassType());
			preparedStatement.setDouble(5,bookingInfo.getTotalFare());
			preparedStatement.setString(6,bookingInfo.getSeatNumber());
			preparedStatement.setString(7,bookingInfo.getCreditCardInfo());
			preparedStatement.setString(8,bookingInfo.getSrcCity());
			preparedStatement.setString(9,bookingInfo.getDestCity());
			
			int rows = preparedStatement.executeUpdate();
			
			if(rows > 0){
				System.out.println("Row is added into db");
				//log.info("Added a row in db now...");
				return ;
			}
			else
				return ;
			
			
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Error in closing db connection");

			}
		}
		
		
	}
	//END bookFlight along with local methods-----------------------------------------------------------------------------------
	
	
	
//=================================================================================================================
//=========================================================================================================================



	// start retrieveBookingDetails
	@Override
	public BookingInformationBean retrieveBookingDetails(int bookingId) throws AirlineException {
		

		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(IQueryMapper.RETRIEVE_BOOKING_DETAIL);

			selectStatement.setInt(1, bookingId);

			ResultSet result = selectStatement.executeQuery();

			while (result.next()) {

				int orderId = result.getInt(1);
				Date orderDateSQL = result.getDate(2);

				java.util.Date orderDate = new java.util.Date(orderDateSQL.getTime());

				OrderDTO order = new OrderDTO();
				
				BookingInformationBean book = new BookingInformationBean();
				book.setBookingId(bookingId);
				book.setCustEmail(result.getString(2));
				book.setNoOfPassengers(result.getInt(3));
				book.set(result.getString(4));
				book.setCustEmail(result.getString(5));
				book.setCustEmail(result.getString(6));
				book.setCustEmail(result.getString(7));
				book.setCustEmail(result.getString(8));
				book.setCustEmail(result.getString(9));
				order.setOrderID(result.getInt(1));
				order.setOrderDate(orderDate);

				return order;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new OrderNotFoundException("order not found",e);
		}

		return null;
	}
	//END retrieveBookingDetails-----------------------------------------------------------------------------------
	
	
	
	// start isValidUserLogin
	@Override
	public UserBean isValidUserLogin(UserBean userDetails) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END isValidUserLogin-----------------------------------------------------------------------------------
	
	
	
	// start fetchGivenCityFlights
	@Override
	public ArrayList<FlightInformationBean> fetchGivenCityFlights(String srcCity, String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END fetchGivenCityFlights-----------------------------------------------------------------------------------
	
	
	
	// start insertFlight
	@Override
	public int insertFlight(FlightInformationBean flightInfo) throws AirlineException {
		// TODO Auto-generated method stub
		return 0;
	}
	//END insertFlight-----------------------------------------------------------------------------------
	
	
	
	// start retrieveAllFlights()
	@Override
	public ArrayList<FlightInformationBean> retrieveAllFlights() throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//ENDretrieveAllFlights()-----------------------------------------------------------------------------------
	
	
	
	// start retrieveFlightDetails
	@Override
	public FlightInformationBean retrieveFlightDetails(int flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END retrieveFlightDetails-----------------------------------------------------------------------------------
	
	
	
	// start deleteFlight
	@Override
	public boolean deleteFlight(int flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END deleteFlight-----------------------------------------------------------------------------------
	
	
	
	// start cancelBooking
	@Override
	public boolean cancelBooking(int bookingId, int passengers) throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END cancelBooking-----------------------------------------------------------------------------------
	
	
	
	// start updateFlight
	@Override
	public int updateFlight(FlightInformationBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return 0;
	}
	//END updateFlight-----------------------------------------------------------------------------------
	
	
	
	// start getCityList()
	@Override
	public ArrayList<String> getCityList() throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END getCityList()-----------------------------------------------------------------------------------
	
	
	
	// start rescheduleBooking
	@Override
	public boolean rescheduleBooking(BookingInformationBean bookingInfo, int flightNo, int passengers)
			throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END rescheduleBooking-----------------------------------------------------------------------------------
	
	
	
	// start fetchGivenPeriodFlights
	@Override
	public ArrayList<FlightInformationBean> fetchGivenPeriodFlights(String airline, Date deptDate1, String deptTime1,
			Date deptDate2, String deptTime2) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END fetchGivenPeriodFlights-----------------------------------------------------------------------------------
	
	
}
