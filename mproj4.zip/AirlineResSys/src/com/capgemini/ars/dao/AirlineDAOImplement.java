package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.capgemini.ars.bean.BookingInformationBean;
import com.capgemini.ars.bean.FlightInformationBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.AirlineException;
import com.capgemini.ars.util.DBUtils;


public class AirlineDAOImplement implements IAirlineDao {
	
	//for db 
	private Connection dbConnection;
	
	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//beans of reqd fields to contain information
	ArrayList<FlightInformationBean> flightList = null;
	//FlightInformationBean flightDetails = null;
	BookingInformationBean bookingDetails = null;
	UserBean userDetails = null;
	ArrayList<String> cityList = null;
	
	//default constructor
	public AirlineDAOImplement() {
		super();
	}

	
	
	// start fetchAvailableFlights
	@Override
	public ArrayList<FlightInformationBean> fetchAvailableFlights(FlightInformationBean flightInfo, String classType,
			int noOfPassengers) throws AirlineException {
		
		if (classType.equalsIgnoreCase("first")) 
		{
		
			
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				preparedStatement=dbConnection.prepareStatement(IQueryMapper.CHECK_FIRST_CLASS_AVAILABILITY);
				
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
					
					flightList.add(flight);
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
		}
		else if (classType.equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.CHECK_BUSINESS_CLASS_AVAILABILITY);
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
					
					flightList.add(flight);
				
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.toString());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
		}
		
		return null;
	}
	//END fetchAvailableFlights-----------------------------------------------------------------------------------
	
//=======================================================================================================================================
//==================================================================================================================================================	
//===================================================================================================================================================================
	
	
	
	// start bookFlight
	@Override
	public int bookFlight(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		
		decOccupancy(bookingInfo, passengers);
		bookDetails(bookingInfo);
		int bookingId = bookingInfo.getBookingId();
		return bookingId;
		
	}
	
	


	//function to reduce the availabe seats after a booking
	private void decOccupancy(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		if (bookingInfo.getClassType().equalsIgnoreCase("first")) 
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			//FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_FIRST_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
			
		}
		else if (bookingInfo.getClassType().equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			//FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_BUSINESS_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			
		}
		
		
	}
	
	
	//for generating booking id using sequence
	private int generateNextBookingId() throws SQLException {
		int id = 0;

		String selectQuery = "SELECT booking_id_seq.NEXTVAL FROM DUAL";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}
	
	//to enter the booking detail inside the db
	private void bookDetails(BookingInformationBean bookingInfo) throws AirlineException 
	{
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		BookingInformationBean book = null;
		
		try
		{
			
			preparedStatement=dbConnection.prepareStatement(IQueryMapper.BOOKING_DETAIL_INSERT);
			preparedStatement.setInt(1,generateNextBookingId());
			preparedStatement.setString(2,bookingInfo.getCustEmail());
			preparedStatement.setInt(3,bookingInfo.getNoOfPassengers());
			preparedStatement.setString(4,bookingInfo.getClassType());
			preparedStatement.setDouble(5,bookingInfo.getTotalFare());
			preparedStatement.setString(6,bookingInfo.getSeatNumber());
			preparedStatement.setString(7,bookingInfo.getCreditCardInfo());
			preparedStatement.setString(8,bookingInfo.getSrcCity());
			preparedStatement.setString(9,bookingInfo.getDestCity());
			
			int rows = preparedStatement.executeUpdate();
			
			if(rows > 0){
				System.out.println("Row is added into db");
				//log.info("Added a row in db now...");
				return ;
			}
			else
				return ;
			
			
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				dbConnection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Error in closing db connection");

			}
		}
		
		
	}
	//END bookFlight along with local methods-----------------------------------------------------------------------------------
	
	
//===============================================================================================================================================	
//=================================================================================================================
//=========================================================================================================================



	// start retrieveBookingDetails
	@Override
	public BookingInformationBean retrieveBookingDetails(int bookingId) throws AirlineException {
		

		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(IQueryMapper.RETRIEVE_BOOKING_DETAIL);

			selectStatement.setInt(1, bookingId);

			ResultSet result = selectStatement.executeQuery();
			
			BookingInformationBean book = new BookingInformationBean();
			while (result.next()) {
									
				
				book.setBookingId(result.getInt(1));
				book.setCustEmail(result.getString(2));
				book.setNoOfPassengers(result.getInt(3));
				book.setClassType(result.getString(4));
				book.setTotalFare(result.getDouble(5));
				book.setSeatNumber(result.getString(6));
				book.setCreditCardInfo(result.getString(7));
				book.setSrcCity(result.getString(8));
				book.setDestCity(result.getString(9));
			
				return book ;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AirlineException("Booking not found");
		}
		return null;

		
	}
	//END retrieveBookingDetails-----------------------------------------------------------------------------------
	
//====================================================================================================================================
//==============================================================================================================================================================
//===========================================================================================================================================================
	
	// start isValidUserLogin
	@Override
	public UserBean isValidUserLogin(UserBean userDetails) throws AirlineException {
		 try 
		 {
			 
		 
			 String selectQuery = "SELECT username,password FROM users";
			 Statement selectStatement = dbConnection.createStatement();
			 ResultSet result = selectStatement.executeQuery(selectQuery);

			 String inputusername = userDetails.getUserName();
			 String inputpassword = userDetails.getPassword();
		
			 while (result.next()) 
			 {
				 
			 
				 String validusername = result.getString("username");
				 String validpassword =  result.getString("password");
				 
				 if ((inputusername.equals(validusername)) && (inputpassword.equals(validpassword)))
				 {
					 	System.out.println("Username and Password matched");
				 }
				 else
					 System.out.println("Login Failed. Either Signup or re-enter the correct credentials");
			 }	
			 
		 }
		 catch (Exception e) 
		 {
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
		 }
		 finally 
		 {
			 try 
				{
					dbConnection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
		}
		
		return null;
	}
	//END isValidUserLogin-----------------------------------------------------------------------------------
	
//===================================================================================================================================
//==================================================================================================================================================
//===============================================================================================================================================================	

	
	// start fetchGivenCityFlights
	@Override
	public ArrayList<FlightInformationBean> fetchGivenCityFlights(String srcCity, String destCity)
			throws AirlineException 
	{
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		FlightInformationBean flight = null;
		BookingInformationBean bookinfo = null;
		
		try
		{
			preparedStatement=dbConnection.prepareStatement(IQueryMapper.FETCH_FLIGHT_GIVEN_SOURCE_AND_DESTINATION);
			
			preparedStatement.setString(1,bookinfo.getSrcCity());
			preparedStatement.setString(2,bookinfo.getDestCity());
			
			resultSet=preparedStatement.executeQuery();
		
			if(resultSet.next())
			{
			
				flight = new FlightInformationBean();
				flight.setFlightNo(resultSet.getInt(1));
				flight.setAirline(resultSet.getString(2));
				flight.setDeptCity(resultSet.getString(3));
				flight.setArrCity(resultSet.getString(4));
				flight.setDeptDate(resultSet.getDate(5));
				flight.setArrDate(resultSet.getDate(6));
				flight.setDeptTime(resultSet.getString(7));
				flight.setArrTime(resultSet.getString(8));
				flight.setFirstSeats(resultSet.getInt(9));
				flight.setFirstSeatsFare(resultSet.getDouble(10));
				flight.setBussSeats(resultSet.getInt(11));
				flight.setBussSeatsFare(resultSet.getDouble(12));
				
				flightList.add(flight);
			}
		
			if( flight != null)
			{
				System.out.println("Record Found Successfully");
				return flightList;
			}
			else
			{
				System.out.println("Record Not Found Successfully");
				return null;
			}
		
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				//connection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Error in closing db connection");


			}
		}
	}
	//END fetchGivenCityFlights-----------------------------------------------------------------------------------
	
//==================================================================================================================================================================
//==============================================================================================================================================================================
//=========================================================================================================================================================================
	
	// start insertFlight
	@Override
	public int insertFlight(FlightInformationBean flightInfo) throws AirlineException {
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		BookingInformationBean book = null;
		
		try
		{
			
			preparedStatement=dbConnection.prepareStatement(IQueryMapper.INSERT_FLIGHT_DETAIL);
			preparedStatement.setInt(1,flightInfo.getFlightNo());
			preparedStatement.setString(2,flightInfo.getAirline());
			preparedStatement.setString(3,flightInfo.getDeptCity());
			preparedStatement.setString(4,flightInfo.getArrCity());
			preparedStatement.setDate(5,flightInfo.getDeptDate());
			preparedStatement.setDate(6,flightInfo.getArrDate());
			preparedStatement.setString(7,flightInfo.getDeptTime());
			preparedStatement.setString(8,flightInfo.getArrTime());
			preparedStatement.setInt(9,flightInfo.getFirstSeats());
			preparedStatement.setDouble(10,flightInfo.getFirstSeatsFare());
			preparedStatement.setInt(11,flightInfo.getBussSeats());
			preparedStatement.setDouble(12,flightInfo.getBussSeatsFare());
			
			int rows = preparedStatement.executeUpdate();
			
			if(rows > 0){
				System.out.println("Row is added into db");
				//log.info("Added a row in db now...");
				return flightInfo.getFlightNo() ;
			}
			else
				return 0 ;
			
			
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new AirlineException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				dbConnection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Error in closing db connection");

			}
		}
	}
	//END insertFlight-----------------------------------------------------------------------------------
//==========================================================================================================================
//=======================================================================================================================
//=================================================================================================================
	
	
	// start retrieveAllFlights()
	@Override
	public ArrayList<FlightInformationBean> retrieveAllFlights() throws AirlineException {
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		FlightInformationBean flight = null;
		try
		{
			preparedStatement=dbConnection.prepareStatement(IQueryMapper.RETRIEVE_ALL_FLIGHTS );
			resultSet=preparedStatement.executeQuery();
		
			if(resultSet.next())
			{
			
				flight = new FlightInformationBean();
				flight.setFlightNo(resultSet.getInt(1));
				flight.setAirline(resultSet.getString(2));
				flight.setDeptCity(resultSet.getString(3));
				flight.setArrCity(resultSet.getString(4));
				flight.setDeptDate(resultSet.getDate(5));
				flight.setArrDate(resultSet.getDate(6));
				flight.setDeptTime(resultSet.getString(7));
				flight.setArrTime(resultSet.getString(8));
				flight.setFirstSeats(resultSet.getInt(9));
				flight.setFirstSeatsFare(resultSet.getDouble(10));
				flight.setBussSeats(resultSet.getInt(11));
				flight.setBussSeatsFare(resultSet.getDouble(12));
				
				flightList.add(flight);
			}
		
			if( flight != null)
			{
				System.out.println("Record Found Successfully");
				return flightList;
			}
			else
			{
				System.out.println("Record Not Found Successfully");
				return null;
			}
		
		}
		catch(Exception e)
		{
			//logger.error(e.getMessage());
			throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		}
		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				//connection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Error in closing db connection");


			}
		}
	}
	//ENDretrieveAllFlights()-----------------------------------------------------------------------------------
	
	
	//==========================================================================================================================
	//=======================================================================================================================
	//=================================================================================================================
	
	
	// start deleteFlight
		@Override
		public boolean deleteFlight(int flightNo) throws AirlineException {
			
			PreparedStatement insertStatement = null;
			String deleteQuery = IQueryMapper.DELETE_FLIGHT;
			
			try
			{
				insertStatement = dbConnection.prepareStatement(deleteQuery);
				insertStatement.setInt(1, flightNo);
				insertStatement.executeUpdate();
			}catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					
					insertStatement.close();
					dbConnection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			
			return true;
		}
		//END deleteFlight-----------------------------------------------------------------------------------
	
		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		
		
		
		// start cancelBooking
		@Override
		public boolean cancelBooking(int bookingId, int passengers) throws AirlineException {
			
			PreparedStatement insertStatement = null;
			
			bookingDetails = retrieveBookingDetails(bookingId);
			String deleteQuery = IQueryMapper.REMOVE_CANCELLED_BOOKING;
			
			try
			{
				incOccupancy(bookingDetails, passengers);
				insertStatement = dbConnection.prepareStatement(deleteQuery);
				
				insertStatement.setInt(1, bookingId);
				
				insertStatement.executeUpdate();
				
				
				
			}catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					
					insertStatement.close();
					dbConnection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}

			
			
			
			
			return true;
		}
		//END cancelBooking-----------------------------------------------------------------------------------
		
		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		
		
		// start updateFlight
		@Override
		public int updateFlight(FlightInformationBean bean) throws AirlineException {
			
			int dataUpdated = -1;
			PreparedStatement insertStatement = null;
			
			String updateQuery = IQueryMapper.UPDATE_FLIGHT_DETAILS;
			
			try
			{
				insertStatement = dbConnection.prepareStatement(updateQuery);
				
				insertStatement.setString(1,bean.getDeptCity());
				insertStatement.setString(2,bean.getArrCity());
				insertStatement.setDate(3,bean.getDeptDate());
				insertStatement.setDate(4,bean.getArrDate());
				insertStatement.setString(5,bean.getDeptTime());
				insertStatement.setString(6,bean.getArrTime());
				insertStatement.setInt(7,bean.getFirstSeats());
				insertStatement.setDouble(8,bean.getFirstSeatsFare());
				insertStatement.setInt(9,bean.getBussSeats());
				insertStatement.setDouble(10,bean.getBussSeatsFare());
				insertStatement.setInt(11,bean.getFlightNo());
				
				dataUpdated = insertStatement.executeUpdate();
				
				
			}catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					
					insertStatement.close();
					dbConnection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			
			
			return dataUpdated;
		}
		//END updateFlight-----------------------------------------------------------------------------------
		
		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================		
		
		
		
		// start rescheduleBooking 
//		This function deselects seats in previous fight and books new seats in a different flight number
		@Override
		public boolean rescheduleBooking(BookingInformationBean bookingInfo, int flightNo, int passengers)
				throws AirlineException {
			
			PreparedStatement insertStatement = null;
			
			incOccupancy(bookingInfo, passengers);
			bookingInfo.setFlightNo(flightNo);
			decOccupancy(bookingInfo, passengers);
			
			String updateQuery = IQueryMapper.UPDATE_BOOKING_INFORMATION;

			
			//	updates bookinginformation table	
			try
			{
				insertStatement = dbConnection.prepareStatement(updateQuery);
				
				insertStatement.setInt(1, flightNo);
				insertStatement.setInt(2, bookingInfo.getBookingId());
				
				insertStatement.executeUpdate();
				
			}catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					
					insertStatement.close();
					dbConnection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			return true;
		
		}
		
		
		// to increment the number of seats in bookinginformation table
				private void incOccupancy (BookingInformationBean bookingInfo, int passengers) throws AirlineException
				{
					
					PreparedStatement insertStatement = null;
					
					if (bookingInfo.getClassType().equals("first")) {
						
						String updateQuery = IQueryMapper.INC_FIRST_CLASS_OCCUPANCY;
						
						try 
						{
							
							insertStatement = dbConnection.prepareStatement(updateQuery);
							insertStatement.setInt(1, passengers);
							insertStatement.setInt(2, bookingInfo.getFlightNo());
							
							insertStatement.executeUpdate();
						}catch(Exception e)
						{
							//logger.error(e.getMessage());
							throw new AirlineException(e.getMessage());
						}
						finally
						{
							try 
							{
							
								insertStatement.close();
								dbConnection.close();
							} 
							catch (SQLException e) 
							{
								//logger.error(e.getMessage());
								throw new AirlineException("Error in closing db connection");

							}
						}
					}
					else if(bookingInfo.getClassType().equals("business"))	
					{
						
						String updateQuery = IQueryMapper.INC_BUSINESS_CLASS_OCCUPANCY;
						
						try 
						{
							
							insertStatement = dbConnection.prepareStatement(updateQuery);
							insertStatement.setInt(1, passengers);
							insertStatement.setInt(2, bookingInfo.getFlightNo());
							
							insertStatement.executeUpdate();
						}catch(Exception e)
						{
							//logger.error(e.getMessage());
							throw new AirlineException(e.getMessage());
						}
						finally
						{
							try 
							{
								
								insertStatement.close();
								dbConnection.close();
							} 
							catch (SQLException e) 
							{
								//logger.error(e.getMessage());
								throw new AirlineException("Error in closing db connection");

							}
						}
					}
						
				}
				
		//END rescheduleBooking with increase occupancy function-----------------------------------------------------------------------------------

		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		
		
		// start fetchGivenPeriodFlights
		@Override
		public ArrayList<FlightInformationBean> fetchGivenPeriodFlights(String airline, Date deptDate1, String deptTime1,
				Date deptDate2, String deptTime2) throws AirlineException {
			

			FlightInformationBean flights = null;
			ArrayList<FlightInformationBean> flightList = null;
			String fetchFlightQuery = IQueryMapper.FETCH_FLIGHT_GIVEN_AIRLINE_AND_PERIOD;
			

			try {
				PreparedStatement selectStatement = dbConnection.prepareStatement(fetchFlightQuery);

				selectStatement.setString(1, airline);
				selectStatement.setDate(2,deptDate1 );
				selectStatement.setDate(3, deptDate2);
				selectStatement.setString(4, deptTime1);
				selectStatement.setString(5, deptTime2);

				ResultSet result = selectStatement.executeQuery();


				while(result.next())
				{
				
					flights = new FlightInformationBean();
					flights.setFlightNo(result.getInt(1));
					flights.setAirline(result.getString(2));
					flights.setDeptCity(result.getString(3));
					flights.setArrCity(result.getString(4));
					flights.setDeptDate(result.getDate(5));
					flights.setArrDate(result.getDate(6));
					flights.setDeptTime(result.getString(7));
					flights.setArrTime(result.getString(8));
					flights.setFirstSeats(result.getInt(9));
					flights.setFirstSeatsFare(result.getDouble(10));
					flights.setBussSeats(result.getInt(11));
					flights.setBussSeatsFare(result.getDouble(12));
					
					flightList.add(flights);
				}
						

					return flightList;
				
			} catch (SQLException e) {
				e.printStackTrace();
				throw new AirlineException("There was a problem in adding flights");
			}
		}


		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		@Override
		public FlightInformationBean retrieveFlightDetails(int flightNo) throws AirlineException {
			
				PreparedStatement insertStatement = null;
				FlightInformationBean flight = null;
				ResultSet result = null;
				
				String retrieveQuery = IQueryMapper.RETRIEVE_FLIGHT_DETAILS;
				
				try
				{
					
					insertStatement = dbConnection.prepareStatement(retrieveQuery);
					insertStatement.setInt(1, flightNo);
					result = insertStatement.executeQuery();
					
					while(result.next())
					{
						
						flight = new FlightInformationBean();
						flight.setFlightNo(result.getInt(1));
						flight.setAirline(result.getString(2));
						flight.setDeptCity(result.getString(3));
						flight.setArrCity(result.getString(4));
						flight.setDeptDate(result.getDate(5));
						flight.setArrDate(result.getDate(6));
						flight.setDeptTime(result.getString(7));
						flight.setArrTime(result.getString(8));
						flight.setFirstSeats(result.getInt(9));
						flight.setFirstSeatsFare(result.getDouble(10));
						flight.setBussSeats(result.getInt(11));
						flight.setBussSeatsFare(result.getDouble(12));
						
						
						
					}
					if( flight != null)
					{
						System.out.println("Record Found Successfully");
						return flight;
					}
					else
					{
						System.out.println("Record Not Found Successfully");
						return null;
					}
				
				}
				catch(Exception e)
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
				}
				finally
				{
					try 
					{
						result.close();
						insertStatement.close();
						//connection.close();
					} 
					catch (SQLException e) 
					{
						//logger.error(e.getMessage());
						throw new AirlineException("Error in closing db connection");


					}
					
					
					
				}
			}
			//END retrieveFlightDetails-----------------------------------------------------------------------------------
			
		


		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		@Override
		public ArrayList<String> getCityList() throws AirlineException {
			// TODO Auto-generated method stub
			return null;
		}
		
		//==========================================================================================================================
		//=======================================================================================================================
		//=================================================================================================================
		
	}
		//END fetchGivenPeriodFlights-----------------------------------------------------------------------------------
		
		


	
	
	

