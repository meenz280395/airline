package com.capgemini.ars.dao;

public interface IQueryMapper {

	/*************************************** CUSTOMER QUERIES **********************************************/
	public static final String CHECK_FIRST_CLASS_AVAILABILITY = "SELECT * FROM FlightInformationBean f WHERE f.deptCity = ? AND f.arrCity = ? AND f.deptDate = ? AND f.firstSeats >= ?";
	public static final String CHECK_BUSINESS_CLASS_AVAILABILITY = "SELECT * FROM FlightInformationBean f WHERE f.deptCity=? AND f.arrCity=? AND f.deptDate=? AND f.bussSeats>=?";
	public static final String DEC_FIRST_CLASS_OCCUPANCY = "UPDATE FlightInformationBean f SET firstSeats=firstSeats-? WHERE flightNo=?";
	public static final String DEC_BUSINESS_CLASS_OCCUPANCY = "UPDATE FlightInformationBean f SET bussSeats=bussSeats-? WHERE flightNo=?";
	//public static final String BOOKING_ID_SEQUENCE = "SELECT booking_id_seq.NEXTVAL FROM DUAL"; 
	public static final String BOOKING_DETAIL_INSERT = "INSERT INTO BookingInformation b VALUES(?,?,?,?,?,?,?,?,?)";
	public static final String RETRIEVE_BOOKING_DETAIL = "SELECT * FROM BookingInformation WHERE bookingId = ?";
	public static final String INSERT_FLIGHT_DETAIL = "INSERT INTO FLIGHTINFORMATION f VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATE_BOOKING_INFORMATION = "UPDATE BookingInformationBean b SET b.flightNo=:fn WHERE b.bookingId=:bi";
	public static final String INC_FIRST_CLASS_OCCUPANCY = "UPDATE FlightInformationBean f SET firstSeats=firstSeats+:pn WHERE flightNo=:fn";
	public static final String INC_BUSINESS_CLASS_OCCUPANCY = "UPDATE FlightInformationBean f SET bussSeats=bussSeats+:pn WHERE flightNo=:fn";
	public static final String REMOVE_CANCELLED_BOOKING = "DELETE FROM BookingInformation WHERE Booking_id = ? ";
	
	/*************************************** AIRLINE EXECUTIVE QUERIES **********************************************/

	public static final String FETCH_FLIGHT_GIVEN_AIRLINE_AND_PERIOD = "SELECT f FROM FlightInformationBean f WHERE f.airline=:air AND dept_date BETWEEN :fd AND :ld AND dept_time BETWEEN :ft AND :lt";
	public static final String FETCH_FLIGHT_GIVEN_SOURCE_AND_DESTINATION = "SELECT * FROM FlightInformationBean f WHERE dept_city=? AND arr_city=?";

	/*************************************** ADMINISTRATOR QUERIES **********************************************/
	public static final String RETRIEVE_ALL_FLIGHTS = "SELECT * FROM FlightInformationBean f";
	public static final String UPDATE_FLIGHT_DETAILS = "UPDATE FlightInformationBean SET dept_city=:dc,arr_city=:ac,dept_date=:dd,arr_date=:ad,dept_time=:dt,arr_time=:at,firstSeats=:fs,firstseatsfare=:fsf,bussseats=:bs,bussseatsfare=:bsf WHERE flightNo =:fn";
	public static final String RETRIEVE_ALL_LOCATIONS = "SELECT f.city FROM LocationBean f";
	public static final String DELETE_FLIGHT = "DELETE FROM FlightInformation WHERE flightno = ? ";
}
