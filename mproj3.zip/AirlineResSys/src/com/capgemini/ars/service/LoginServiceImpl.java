package com.capgemini.ars.service;



import java.sql.SQLException;

import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.IAirlineDao;
import com.capgemini.ars.exception.AirlineException;


public class LoginServiceImpl implements ILoginService {

	
	IAirlineDao airlineDao;

	public IAirlineDao getAirlineDao() {
		return airlineDao;
	}

	public void setAirlineDao(IAirlineDao airlineDao) {
		this.airlineDao = airlineDao;
	}

	@Override
	public UserBean isValidUserLogin(UserBean userDetails)
			throws AirlineException {

		return airlineDao.isValidUserLogin(userDetails);
	}

}
