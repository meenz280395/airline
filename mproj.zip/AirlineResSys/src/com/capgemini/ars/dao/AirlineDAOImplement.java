package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.ars.bean.BookingInformationBean;
import com.capgemini.ars.bean.FlightInformationBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.exception.AirlineException;


public class AirlineDAOImplement implements IAirlineDao {
	
	//beans of reqd fields to contain information
	ArrayList<FlightInformationBean> flightList = null;
	FlightInformationBean flightDetails = null;
	BookingInformationBean bookingDetails = null;
	UserBean userDetails = null;
	ArrayList<String> cityList = null;
	
	//default constructor
	public AirlineDAOImplement() {
		super();
	}

	
	
	// start fetchAvailableFlights
	@Override
	public ArrayList<FlightInformationBean> fetchAvailableFlights(FlightInformationBean flightInfo, String classType,
			int noOfPassengers) throws AirlineException {
		
		if (classType.equalsIgnoreCase("first")) 
		{
		
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.CHECK_FIRST_CLASS_AVAILABILITY);
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
		}
		else if (classType.equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.CHECK_BUSINESS_CLASS_AVAILABILITY);
				preparedStatement.setString(1,flightInfo.getDeptCity());
				preparedStatement.setString(2,flightInfo.getArrCity());
				preparedStatement.setDate(3,flightInfo.getDeptDate());
				preparedStatement.setInt(4,noOfPassengers);
				resultSet=preparedStatement.executeQuery();
			
				if(resultSet.next())
				{
				
					flight = new FlightInformationBean();
					flight.setFlightNo(resultSet.getInt(1));
					flight.setAirline(resultSet.getString(2));
					flight.setDeptCity(resultSet.getString(3));
					flight.setArrCity(resultSet.getString(4));
					flight.setDeptDate(resultSet.getDate(5));
					flight.setArrDate(resultSet.getDate(6));
					flight.setDeptTime(resultSet.getString(7));
					flight.setArrTime(resultSet.getString(8));
					flight.setFirstSeats(resultSet.getInt(9));
					flight.setFirstSeatsFare(resultSet.getDouble(10));
					flight.setBussSeats(resultSet.getInt(11));
					flight.setBussSeatsFare(resultSet.getDouble(12));
				
				}
			
				if( flight != null)
				{
					System.out.println("Record Found Successfully");
					return flightList;
				}
				else
				{
					System.out.println("Record Not Found Successfully");
					return null;
				}
			
			}
			catch(Exception e)
			{
				//logger.error(e.getMessage());
				throw new AirlineException(e.toString());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
		}
		
		return null;
	}
	//END fetchAvailableFlights-----------------------------------------------------------------------------------
	
	
	
	// start bookFlight
	@Override
	public int bookFlight(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		
		decOccupancy(bookingInfo, passengers);
		bookDetails(bookingInfo);
		int bookingId = bookingInfo.getBookingId();
		return bookingId;
		
	}
	
	


//function to reduce the availabe seats after a booking
	private void decOccupancy(BookingInformationBean bookingInfo, int passengers) throws AirlineException 
	{
		if (bookingInfo.getClassType().equalsIgnoreCase("first")) 
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_FIRST_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");


				}
			}
			
			
		}
		else if (bookingInfo.getClassType().equalsIgnoreCase("business"))
		{
			//Connection connection=DBConnection.getInstance().getConnection();

			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			FlightInformationBean flight = null;
			try
			{
				//preparedStatement=connection.prepareStatement(IQueryMapper.DEC_BUSINESS_CLASS_OCCUPANCY);
				preparedStatement.setInt(1,passengers);
				preparedStatement.setInt(2,bookingInfo.getFlightNo());
				resultSet=preparedStatement.executeQuery();
				
			}
			catch(Exception e)
			{
				//logger.info(e.getMessage());
				throw new AirlineException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					//connection.close();
				} 
				catch (SQLException e) 
				{
					//logger.error(e.getMessage());
					throw new AirlineException("Error in closing db connection");

				}
			}
			
		}
		
		
	}
	
	//the details projected after booking
	private void bookDetails(BookingInformationBean bookingInfo) 
	{
		// TODO Auto-generated method stub
		
	}
	//END bookFlight along with local methods-----------------------------------------------------------------------------------
	
	
	
	



	// start retrieveBookingDetails
	@Override
	public BookingInformationBean retrieveBookingDetails(int bookingId) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END retrieveBookingDetails-----------------------------------------------------------------------------------
	
	
	
	// start isValidUserLogin
	@Override
	public UserBean isValidUserLogin(UserBean userDetails) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END isValidUserLogin-----------------------------------------------------------------------------------
	
	
	
	// start fetchGivenCityFlights
	@Override
	public ArrayList<FlightInformationBean> fetchGivenCityFlights(String srcCity, String destCity)
			throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END fetchGivenCityFlights-----------------------------------------------------------------------------------
	
	
	
	// start insertFlight
	@Override
	public int insertFlight(FlightInformationBean flightInfo) throws AirlineException {
		// TODO Auto-generated method stub
		return 0;
	}
	//END insertFlight-----------------------------------------------------------------------------------
	
	
	
	// start retrieveAllFlights()
	@Override
	public ArrayList<FlightInformationBean> retrieveAllFlights() throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//ENDretrieveAllFlights()-----------------------------------------------------------------------------------
	
	
	
	// start retrieveFlightDetails
	@Override
	public FlightInformationBean retrieveFlightDetails(int flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END retrieveFlightDetails-----------------------------------------------------------------------------------
	
	
	
	// start deleteFlight
	@Override
	public boolean deleteFlight(int flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END deleteFlight-----------------------------------------------------------------------------------
	
	
	
	// start cancelBooking
	@Override
	public boolean cancelBooking(int bookingId, int passengers) throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END cancelBooking-----------------------------------------------------------------------------------
	
	
	
	// start updateFlight
	@Override
	public int updateFlight(FlightInformationBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return 0;
	}
	//END updateFlight-----------------------------------------------------------------------------------
	
	
	
	// start getCityList()
	@Override
	public ArrayList<String> getCityList() throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END getCityList()-----------------------------------------------------------------------------------
	
	
	
	// start rescheduleBooking
	@Override
	public boolean rescheduleBooking(BookingInformationBean bookingInfo, int flightNo, int passengers)
			throws AirlineException {
		// TODO Auto-generated method stub
		return false;
	}
	//END rescheduleBooking-----------------------------------------------------------------------------------
	
	
	
	// start fetchGivenPeriodFlights
	@Override
	public ArrayList<FlightInformationBean> fetchGivenPeriodFlights(String airline, Date deptDate1, String deptTime1,
			Date deptDate2, String deptTime2) throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	//END fetchGivenPeriodFlights-----------------------------------------------------------------------------------
	
	
}
