package com.capgemini.ars.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.bean.BookingInformationBean;
import com.capgemini.ars.bean.FlightInformationBean;
import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.AirlineDAOImplement;
import com.capgemini.ars.dao.IAirlineDao;
import com.capgemini.ars.exception.AirlineException;
import com.capgemini.ars.service.IAdminService;
import com.capgemini.ars.service.IAirlineExecutiveService;
import com.capgemini.ars.service.ILoginService;
import com.capgemini.ars.service.IUserService;
import com.capgemini.ars.service.IRegisterService;


public class Client {
	
	
	static Scanner sc = new Scanner(System.in);
	static IAdminService adminService = null;
	static ILoginService loginService = null;
	static IAirlineExecutiveService execService = null;
	static IUserService userService = null;
	static IRegisterService registerService = null;
	//static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) throws AirlineException, SQLException 
	{
		
		AirportBean airportBean = null;
		BookingInformationBean bookingInfoBean = null;
		FlightInformationBean flightInfoBean = null;
		UserBean userBean = null;
		
		while (true) 
		{

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   AIRLINE RESERVATION SYSTEM ");
			System.out.println("_______________________________\n");
			System.out.println("Select your User category");
			System.out.println("1.Customer ");
			System.out.println("2.Log In for existing Admin/Exe");
			System.out.println("3.Register for new Admin/Exe");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option
		
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				
				customerUser();
				break;
				
			case 2: 
				loginUser();
				break;
			
			case 3:
				registerUser();
				break;
				
			case 4:
				System.out.print("Exit Airline Reservation System");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[1-4]");
		
		
			}
			
			
		}
		
		
		
		
		
	}
	
	
	private static void customerUser() throws AirlineException
	{
		AirportBean airportBean = null;
		BookingInformationBean bookingInfoBean = null;
		FlightInformationBean flightInfoBean = null;
		UserBean userBean = null;
		
		System.out.println("Hello there, customer!");
		
		System.out.println();
		System.out.println();
		System.out.println("1. Fetch Available Flights ");
		System.out.println("2. Book Flight");
		System.out.println("3. Retrieve Booking  Details");
		System.out.println("4. Retrieve FLight Details");
		System.out.println("5. Reschedule Booking");
		System.out.println("6. Cancel Booking");
		System.out.println("________________________________");
		System.out.println("Select an option:");
		
		int choice2 = sc.nextInt();
		
		switch (choice2) {
		case 1: 
			
			
			System.out.println();
			System.out.println();
			
			System.out.println("Enter source city");
			String srcCity = sc.nextLine();
			flightInfoBean.setDeptCity(srcCity);
			
			System.out.println("Enter destination city");
			String arrCity = sc.nextLine();
			flightInfoBean.setArrCity(arrCity);
			
			
			System.out.println("Enter departure date");
//			Date deptDate = sc.nextDate();
			//flightInfoBean.setDeptDate(deptDate);

			System.out.println("Enter Class type");
			System.out.println("Enter first for First Class Seats or business for Business Class Seats");
			String classType = sc.next();
								
			System.out.println("Enter the number of passengers");
			int noOfPassengers = sc.nextInt();
			
			ArrayList<FlightInformationBean> flights = userService.fetchAvailableFlights(flightInfoBean, classType, noOfPassengers);
			
			System.out.println("Your Details are:");
			
			Iterator<FlightInformationBean> i = flights.iterator();
			while(i.hasNext())
			{
				FlightInformationBean f = i.next();
				System.out.println("Flight number = " + f.getFlightNo());
				System.out.println("Airline = " + f.getAirline());
				System.out.println("Source City = " + f.getDeptCity());
				System.out.println("Destination City = " + f.getArrCity());
//				System.out.println("Departure Date = " + f.get);
				System.out.println("Arrival Date  = " + f.getFlightNo());
				System.out.println("Departure Time = " + f.getFlightNo());
				System.out.println("Arrival Time = " + f.getFlightNo());
				System.out.println("Number of First Class Seats Available = " + f.getFlightNo());
				System.out.println("First Class Fare = " + f.getFlightNo());
				System.out.println("Number of Business Class Seats Available = " + f.getFlightNo());
				System.out.println("Business Class Fare = " + f.getFlightNo());

			}
			
			
			
			
			break;
			
			
		case 2 :
			
			System.out.println();
			System.out.println();
			
			System.out.println("Booking id");
			int bookingId = sc.nextInt();
			bookingInfoBean.setBookingId(bookingId);
			
			System.out.println("Enter your Email Id");
			String custEmail = sc.next();
			bookingInfoBean.setCustEmail(custEmail);
			
			System.out.println("Enter number of passengers");
			int noOfPassengers1 = sc.nextInt();
//			bookingInfoBean.setNoOfPassengers(noOfPassengers1);
		
			System.out.println("Enter Class type");
			System.out.println("Enter first for First Class Seats or business for Business Class Seats");
			String classType1 = sc.next();
			bookingInfoBean.setClassType(classType1);
			
			System.out.println("total fare");
			Double fare = sc.nextDouble();
			bookingInfoBean.setTotalFare(fare);
			
			System.out.println("Seat number");
			String seat = sc.next();
			bookingInfoBean.setSeatNumber(seat);
			
			System.out.println("Credit card information");
			String credit = sc.next();
			bookingInfoBean.setCreditCardInfo(credit);
			
			System.out.println("Enter source city");
			String srcCity1 = sc.next();
			bookingInfoBean.setSrcCity(srcCity1);
			
			System.out.println("Enter destination City");
			String destCity = sc.next();
			bookingInfoBean.setDestCity(destCity);
			
			System.out.println("Enter departure date");
			String tempDeptDate = sc.next();
//			bookingInfoBean.setTempDeptDate(tempDeptDate);
		
			int Id = userService.bookFlight(bookingInfoBean,noOfPassengers1);
			
			System.out.println("Your booking id is " + Id);
			
			break;
			
			
		case 3 : 
			
			System.out.println();
			System.out.println();
			
			System.out.println("Enter your Booking id");
			int bookingId1 = sc.nextInt();
			bookingInfoBean.setBookingId(bookingId1);
			
			bookingInfoBean = userService.retrieveBookingDetails(bookingId1);
			
			while(true)
			{
				
				System.out.println("Booking Id " + bookingInfoBean.getBookingId());
				System.out.println("Email id " + bookingInfoBean.getCustEmail());
				System.out.println("Number of passengers " + bookingInfoBean.getNoOfPassengers());
				System.out.println("Class type is " + bookingInfoBean.getClassType()  );
				System.out.println("Total fare " + bookingInfoBean.getTotalFare());
				System.out.println("Seat number " + bookingInfoBean.getSeatNumber());
				System.out.println("Credit Card Information" + bookingInfoBean.getCreditCardInfo());
				System.out.println("Source city is" + bookingInfoBean.getSrcCity());
				System.out.println("Destination city is " + bookingInfoBean.getDestCity());
				
				System.out.println();
				System.out.println();
				
				break;
			}
			
			break;
			
		case 4 :
			
			System.out.println();
			System.out.println();
			System.out.println("Enter Flight number");
			int flightNo = sc.nextInt();
			
			flightInfoBean = userService.retrieveFlightDetails(flightNo);
			
			System.out.println();
			System.out.println();
			System.out.println("Flight number = " + flightInfoBean.getFlightNo());
			System.out.println("Airline = " + flightInfoBean.getAirline());
			System.out.println("Source City = " + flightInfoBean.getDeptCity());
			System.out.println("Destination City = " + flightInfoBean.getArrCity());
//			System.out.println("Departure Date = " + f.get);
			System.out.println("Arrival Date  = " + flightInfoBean.getFlightNo());
			System.out.println("Departure Time = " + flightInfoBean.getFlightNo());
			System.out.println("Arrival Time = " + flightInfoBean.getFlightNo());
			System.out.println("Number of First Class Seats Available = " + flightInfoBean.getFlightNo());
			System.out.println("First Class Fare = " + flightInfoBean.getFlightNo());
			System.out.println("Number of Business Class Seats Available = " + flightInfoBean.getFlightNo());
			System.out.println("Business Class Fare = " + flightInfoBean.getFlightNo());
			
			break;
			
		case 5 :
			
			System.out.println();
			System.out.println();
			System.out.println("Enter Flight number");
			int flightno = sc.nextInt();
			
			System.out.println("Enter number of passengers");
			int passengers = sc.nextInt();
			
			boolean res = userService.rescheduleBooking(bookingInfoBean, flightno, passengers);
			
			if(res == true)
			{
				System.out.println("Booking rescheduled successfully");
			}
			else
				System.out.println("Rescheduling failed");
			
			
			break;
		
			
		case 6 :
			
			System.out.println();
			System.out.println();
			System.out.println("Enter Booking Id");
			int bookId = sc.nextInt();
			
			int np = 0;
			
			boolean res1 = userService.cancelBooking(bookId, np);
			
			if(res1 == true)
			{
				System.out.println("Booking cancelled successfully");
			}
			else
				System.out.println("Cancel failed");
			
			break;
			
			
			
		
		default:
			
			System.out.println("Enter valid option");
			break;
		}



		
		
	}
	
	

	private static void registerUser() throws AirlineException, SQLException 
	{
		
		
		UserBean userBean = null;
		
		//taking input of user for registration
		
		System.out.println("Enter a username\n");
		String username = sc.nextLine();
		userBean.setUserName(username);
		
		System.out.println("Enter a password\n");
		String password = sc.nextLine();
		userBean.setPassword(password);
		
		System.out.println("Enter a role (Admin or Executive)");
		String role = sc.nextLine();
		userBean.setRole(role);
		
		System.out.println("Enter a mobile number\n");
		long mobileno = sc.nextLong();
		userBean.setMobileNo(mobileno);
		
		registerService.addUser(userBean);
		
		System.out.println("Redirecting to login");
		loginUser();
		
	}
	//end of register user

	private static void loginUser() throws AirlineException {
		
		UserBean userBean = null;
		
		System.out.println("Enter your valid username : \n");
		String inputusername = sc.nextLine();
		userBean.setUserName(inputusername);
		
		System.out.println("Enter your valid password : \n");
		String inputpassword=sc.nextLine();
		userBean.setPassword(inputpassword);
		
		String role = loginService.isValidUserLogin(userBean);
		
		if(role.equalsIgnoreCase("admin"))
		{
			adminRole();
		}
		else if(role.equalsIgnoreCase("executive"))
		{
			executiveRole();
		}
		else
		{
			System.out.println("Check login credentials or register yourself");
		}
	}
	
	
	
// if the user is an executive then
	private static void executiveRole() throws AirlineException 
	{
		AirportBean airportBean = null;
		BookingInformationBean bookingInfoBean = null;
		FlightInformationBean flightInfoBean = null;
		UserBean userBean = null;
		
		
		//function options for executive
		System.out.println("Hello! ");
		System.out.println("_______________________________\n");
		System.out.println("Kindly choose what you want to do");
		System.out.println("1. Fetch flights between two cities");
		System.out.println("2. Fetch flights in a particular time range");
		System.out.println("3. Exit");
		System.out.println("________________________________");
		System.out.println("Select an option:");
		
		int choice3 = sc.nextInt();
		
		switch (choice3) 
		{
		
		//fetching and printing flights between two cities
		case 1:
		{
			System.out.println("Enter the source city : ");
			String inputSrcCity = sc.nextLine();
			
			System.out.println("Enter the destiation city : ");
			String inputDestCity = sc.nextLine();
			
			ArrayList<FlightInformationBean> flights = execService.fetchGivenCityFlights(inputSrcCity, inputDestCity);
			System.out.println("Your Details are:");
			
			Iterator<FlightInformationBean> i = flights.iterator();
			
			while(i.hasNext())
			{
				FlightInformationBean f = i.next();
				System.out.println("Flight number = " + f.getFlightNo());
				System.out.println("Airline = " + f.getAirline());
				System.out.println("Source City = " + f.getDeptCity());
				System.out.println("Destination City = " + f.getArrCity());
				System.out.println("Departure Date = " + f.getDeptDate());
				System.out.println("Arrival Date  = " + f.getFlightNo());
				System.out.println("Departure Time = " + f.getFlightNo());
				System.out.println("Arrival Time = " + f.getFlightNo());
				System.out.println("Number of First Class Seats Available = " + f.getFlightNo());
				System.out.println("First Class Fare = " + f.getFlightNo());
				System.out.println("Number of Business Class Seats Available = " + f.getFlightNo());
				System.out.println("Business Class Fare = " + f.getFlightNo());
			}
			
			while(true)
			{
				System.out.println("FlightNo is: "  );
			}
			
		}
		break;
		
		//fetching flights in a particular time
		
		case 2:
		{
			System.out.println("Enter Airline : ");
			String inputAirline = sc.next();
			
			System.out.println("Enter departure date range : ");
			System.out.println("Start date : ");
			Date deptDate1 = sc.//nextDate();
			System.out.println("End date : ");
			Date deptDate2 = sc.//nextDate();
			
			System.out.println("Enter departure time range : ");
			System.out.println(" Start time : ");
			String deptTime1 = sc.next();
			System.out.println(" End time : ");
			String deptTime2 = sc.next();
			
			ArrayList<FlightInformationBean> flights = execService.fetchGivenPeriodFlights(inputAirline, deptDate1, deptTime1, deptDate2 , deptTime2);
			System.out.println("Your Details are:");
			
			Iterator<FlightInformationBean> i = flights.iterator();
			
			while(i.hasNext())
			{
				FlightInformationBean f = i.next();
				System.out.println("Flight number = " + f.getFlightNo());
				System.out.println("Airline = " + f.getAirline());
				System.out.println("Source City = " + f.getDeptCity());
				System.out.println("Destination City = " + f.getArrCity());
				System.out.println("Departure Date = " + f.getDeptDate());
				System.out.println("Arrival Date  = " + f.getFlightNo());
				System.out.println("Departure Time = " + f.getFlightNo());
				System.out.println("Arrival Time = " + f.getFlightNo());
				System.out.println("Number of First Class Seats Available = " + f.getFlightNo());
				System.out.println("First Class Fare = " + f.getFlightNo());
				System.out.println("Number of Business Class Seats Available = " + f.getFlightNo());
				System.out.println("Business Class Fare = " + f.getFlightNo());
			}
			
			while(true)
			{
				System.out.println("FlightNo is: "  );
			}
			
		}
			break;
			
		case 3:
			System.out.print("Exit Airline Reservation System");
			System.exit(0);
			break;
			
		default:
			System.out.println("Enter a valid option[1-3]");
	
		}
		
	}

	private static void adminRole() {
		// functions for admin
		
		AirportBean airportBean = null;
		BookingInformationBean bookingInfoBean = null;
		FlightInformationBean flightInfoBean = null;
		UserBean userBean = null;
		
				System.out.println("Hello! ");
				System.out.println("_____________________________________________________\n");
				System.out.println("Kindly choose what you want to do");
				System.out.println("1. Insert flight information");
				System.out.println("2. Retrieve all flights");
				System.out.println("3. Retrive flight detail by Flight Number");
				System.out.println("4. Delete existing flight");
				System.out.println("5. Update existing flight");
				System.out.println("6. Exit");
				System.out.println("______________________________________________________");
				System.out.println("Select an option:");
				
				int choice4 = sc.nextInt();
				
				switch (choice4) 
				{
				case 1:
				{
					System.out.println("Enter flight number : ");
					int inputFlightNumber = sc.nextInt();
					flightInfoBean.setFlightNo(inputFlightNumber);
					
					System.out.println("Enter corresponding airline : ");
					String inputAirline = sc.next();
					flightInfoBean.setAirline(inputAirline);
					
					System.out.println("Enter source city : ");
					String inputDeptCity = sc.next();
					flightInfoBean.setDeptCity(inputDeptCity);

					System.out.println("Enter destination city : ");
					String inputArrCity = sc.next();
					flightInfoBean.setArrCity(inputArrCity);
					
					System.out.println("Enter departure date : ");
					Date inputDeptDate = //sc.next();
					flightInfoBean.setDeptDate(inputDeptDate);
					
					System.out.println("Enter arrival date : ");
					Date inputArrDate = //sc.next();
					flightInfoBean.setArrDate(inputArrDate);
					
					System.out.println("Enter departure time : ");
					String inputDeptTime = sc.next();
					flightInfoBean.setDeptTime(inputDeptTime);
					
					System.out.println("Enter arrival time : ");
					String inputArrTime = sc.next();
					flightInfoBean.setArrTime(inputArrTime);
					
					System.out.println("Enter number of First class seats : ");
					int inputFirstSeat = sc.nextInt();
					flightInfoBean.setFirstSeats(inputFirstSeat);
					
					System.out.println("Enter First Class seat fare : ");
					double inputFirstFare = sc.nextDouble();
					flightInfoBean.setFirstSeatsFare(inputFirstFare);
					
					System.out.println("Enter number of Business class seats : ");
					int inputBussSeat = sc.nextInt();
					flightInfoBean.setBussSeats(inputBussSeat);
					
					System.out.println("Enter Business Class seat fare : ");
					double inputBussFare = sc.nextDouble();
					flightInfoBean.setBussSeatsFare(inputBussFare);
					
					int addFlight = adminService.insertFlight(flightInfoBean) ;
					
					if(addFlight > 0)
						System.out.println("Insertion successfull");
					else
						System.out.println("Insertion failed, Try again!");
					
				}
					break;
					
				case 2://retrieve all flights
				{
					
					ArrayList<FlightInformationBean> flights = adminService.retrieveAllFlights();
					
					System.out.println("Your Details are:");
					
					Iterator<FlightInformationBean> i = flights.iterator();
					
					while(i.hasNext())
					{
						FlightInformationBean f = i.next();
						System.out.println("Flight number = " + f.getFlightNo());
						System.out.println("Airline = " + f.getAirline());
						System.out.println("Source City = " + f.getDeptCity());
						System.out.println("Destination City = " + f.getArrCity());
						System.out.println("Departure Date = " + f.getDeptDate());
						System.out.println("Arrival Date  = " + f.getFlightNo());
						System.out.println("Departure Time = " + f.getFlightNo());
						System.out.println("Arrival Time = " + f.getFlightNo());
						System.out.println("Number of First Class Seats Available = " + f.getFlightNo());
						System.out.println("First Class Fare = " + f.getFlightNo());
						System.out.println("Number of Business Class Seats Available = " + f.getFlightNo());
						System.out.println("Business Class Fare = " + f.getFlightNo());
					}
					
					while(true)
					{
						System.out.println("FlightNo is: "  );
					}
				}
					break;
					
				case 3://retrieve flight by id
				{
					System.out.println("Enter Fight number to retrieve flight details : ");
					int inputFlightNo = sc.nextInt();
					
					
					FlightInformationBean f = adminService.retrieveFlightDetails(inputFlightNo);
					
					System.out.println("Flight number = " + f.getFlightNo());
					System.out.println("Airline = " + f.getAirline());
					System.out.println("Source City = " + f.getDeptCity());
					System.out.println("Destination City = " + f.getArrCity());
					System.out.println("Departure Date = " + f.getDeptDate());
					System.out.println("Arrival Date  = " + f.getFlightNo());
					System.out.println("Departure Time = " + f.getFlightNo());
					System.out.println("Arrival Time = " + f.getFlightNo());
					System.out.println("Number of First Class Seats Available = " + f.getFlightNo());
					System.out.println("First Class Fare = " + f.getFlightNo());
					System.out.println("Number of Business Class Seats Available = " + f.getFlightNo());
					System.out.println("Business Class Fare = " + f.getFlightNo());
				
				}
					break;
					
				case 4:
				{
					System.out.println("Enter Flight number of flight to be deleted : ");
					int inputFlightNo = sc.nextInt();
					flightInfoBean.setFlightNo(inputFlightNo);
					
					adminService.deleteFlight(inputFlightNo);
					
				}
					break;
					
				case 5:
				{
					System.out.println("Emter flight number of flight to be updated : ");
					int inputFlightNo =sc.nextInt();
					flightInfoBean.setFlightNo(inputFlightNo);
					
					System.out.println("Enter the following details for updation : ");
					System.out.println("Enter corresponding airline : ");
					String inputAirline = sc.next();
					flightInfoBean.setAirline(inputAirline);
					
					System.out.println("Enter source city : ");
					String inputDeptCity = sc.next();
					flightInfoBean.setDeptCity(inputDeptCity);

					System.out.println("Enter destination city : ");
					String inputArrCity = sc.next();
					flightInfoBean.setArrCity(inputArrCity);
					
					System.out.println("Enter departure date : ");
					Date inputDeptDate = //sc.next();
					flightInfoBean.setDeptDate(inputDeptDate);
					
					System.out.println("Enter arrival date : ");
					Date inputArrDate = //sc.next();
					flightInfoBean.setArrDate(inputArrDate);
					
					System.out.println("Enter departure time : ");
					String inputDeptTime = sc.next();
					flightInfoBean.setDeptTime(inputDeptTime);
					
					System.out.println("Enter arrival time : ");
					String inputArrTime = sc.next();
					flightInfoBean.setArrTime(inputArrTime);
					
					System.out.println("Enter number of First class seats : ");
					int inputFirstSeat = sc.nextInt();
					flightInfoBean.setFirstSeats(inputFirstSeat);
					
					System.out.println("Enter First Class seat fare : ");
					double inputFirstFare = sc.nextDouble();
					flightInfoBean.setFirstSeatsFare(inputFirstFare);
					
					System.out.println("Enter number of Business class seats : ");
					int inputBussSeat = sc.nextInt();
					flightInfoBean.setBussSeats(inputBussSeat);
					
					System.out.println("Enter Business Class seat fare : ");
					double inputBussFare = sc.nextDouble();
					flightInfoBean.setBussSeatsFare(inputBussFare);
					
					int dataUpdate = adminService.updateFlight(flightInfoBean);
					
					if(dataUpdate > 0)
						System.out.println("Update successfull");
					else
						System.out.println("Update failed, Try again!");
				}
					break;
					
				case 6:
					System.out.print("Exit Airline Reservation System");
					System.exit(0);
					break;
					
				default:
					System.out.println("Enter a valid option[1-3]");
			
				}
		
	}

}